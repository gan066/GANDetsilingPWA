from django.shortcuts import render, redirect, get_object_or_404
from .models import Client
from .forms import ClientForm
from .forms import ServiceForm
from .models import Service


def index(request):
    return render(request, 'core/base.html')
def clients(request):
    return render(request, 'core/clients.html')

def services(request):
    return render(request, 'core/services.html')

def settings(request):
    return render(request, 'core/settings.html')

def clients_list(request):
    """Отображает список всех клиентов"""
    clients = Client.objects.all()  # Получаем всех клиентов из базы
    return render(request, 'core/clients_list.html', {'clients': clients})

def clients_list(request):
    """Отображает список клиентов"""
    return render(request, 'core/clients.html')

def client_create(request):
    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            client = form.save()
            client.services.set(form.cleaned_data['services'])  # Сохраняем выбранные услуги
            return redirect('clients_list')
    else:
        form = ClientForm()
    return render(request, 'core/client_form.html', {'form': form})

def home(request):
    """Домашняя страница"""
    return render(request, 'core/home.html')

def clients_list(request):
    clients = Client.objects.all()
    print(clients)  # Отладочный вывод
    return render(request, 'core/clients_list.html', {'clients': clients})

def clients_list(request):
    clients = Client.objects.prefetch_related('ordered_services').all()  # Используем correct related_name
    return render(request, 'core/clients_list.html', {'clients': clients})

def client_edit(request, client_id):
    client = get_object_or_404(Client, id=client_id)
    if request.method == 'POST':
        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()
            return redirect('clients_list')
    else:
        form = ClientForm(instance=client)
    return render(request, 'core/client_edit.html', {'form': form, 'client': client})

def service_list(request):
    services = Service.objects.all()
    return render(request, 'core/service_list.html', {'services': services})

def service_create(request):
    if request.method == 'POST':
        form = ServiceForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('service_list')
    else:
        form = ServiceForm()
    return render(request, 'core/service_form.html', {'form': form, 'title': 'Добавить услугу'})

def service_edit(request, service_id):
    service = get_object_or_404(Service, id=service_id)
    if request.method == 'POST':
        form = ServiceForm(request.POST, instance=service)
        if form.is_valid():
            form.save()
            return redirect('service_list')
    else:
        form = ServiceForm(instance=service)
    return render(request, 'core/service_form.html', {'form': form, 'title': 'Редактировать услугу'})

def service_delete(request, service_id):
    service = get_object_or_404(Service, id=service_id)
    if request.method == 'POST':
        service.delete()
        return redirect('service_list')
    return render(request, 'core/service_confirm_delete.html', {'service': service})
