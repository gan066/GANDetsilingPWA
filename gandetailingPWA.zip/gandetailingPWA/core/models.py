from django.db import models

class Client(models.Model):
    name = models.CharField(max_length=100, verbose_name="Имя клиента")
    phone = models.CharField(max_length=15, verbose_name="Телефон")
    email = models.EmailField(blank=True, null=True, verbose_name="Электронная почта")
    car_model = models.CharField(max_length=100, verbose_name="Модель автомобиля")
    date_received = models.DateField(verbose_name="Дата приёма")
    date_returned = models.DateField(blank=True, null=True, verbose_name="Дата сдачи")
    services = models.ManyToManyField('Service', related_name='clients_of_service', verbose_name="Услуги", blank=True)

    def __str__(self):
        return f"{self.name} ({self.car_model})"


class Service(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название услуги")
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Стоимость")
    clients = models.ManyToManyField('Client', related_name='ordered_services', verbose_name="Клиенты", blank=True)

    def __str__(self):
        return self.name
