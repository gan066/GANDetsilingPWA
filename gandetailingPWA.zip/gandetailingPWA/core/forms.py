from django import forms
from .models import Client, Service

class ClientForm(forms.ModelForm):
    class ClientForm(forms.ModelForm):
        services = forms.ModelMultipleChoiceField(
            queryset=Service.objects.all(),
            widget=forms.CheckboxSelectMultiple,
            required=False,
            label="Выберите услуги"
        )
    class Meta:
        model = Client
        fields = ['name', 'phone', 'email', 'car_model', 'date_received', 'date_returned', 'services']
        widgets = {
            'date_received': forms.DateInput(attrs={'type': 'date'}),
            'date_returned': forms.DateInput(attrs={'type': 'date'}),
        }

class ServiceForm(forms.ModelForm):
    class Meta:
        model = Service
        fields = ['name', 'price']
        labels = {
            'name': 'Название услуги',
            'price': 'Цена',
        }