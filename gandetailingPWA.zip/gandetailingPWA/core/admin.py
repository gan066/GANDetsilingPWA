from django.contrib import admin
from .models import Client

@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display = ('name', 'phone', 'car_model', 'date_received', 'date_returned')
    search_fields = ('name', 'phone', 'car_model')
    list_filter = ('date_received', 'date_returned')
