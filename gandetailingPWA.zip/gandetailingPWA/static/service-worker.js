// Название кэша
const CACHE_NAME = 'django-pwa-v1';

// Какие файлы кэшировать сразу
const urlsToCache = [
  '/',
  '/static/manifest.json',
  '/static/img/icons/icon-192.png',
  '/static/img/icons/icon-512.png',
  // добавьте сюда CSS/JS, когда появятся
];

// Установка service worker и кэширование файлов
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(urlsToCache);
    })
  );
});

// Активация service worker
self.addEventListener('activate', (event) => {
  event.waitUntil(self.clients.claim());
});

// Интерцепция запросов и возвращение кэшированных ответов, если есть
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});
