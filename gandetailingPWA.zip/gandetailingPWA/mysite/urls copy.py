from django.contrib import admin
from django.urls import path, include
from core import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),  # Стандартный маршрут для Django Admin
    path('clients/', views.clients_list, name='clients_list'),
    path('services/', views.services, name='services'),
    path('services/', include('core.urls')),
    path('settings/', views.settings, name='settings'),
    path('clients/new/', views.client_create, name='client_create'),
    path('', views.home, name='home'),  # Добавляем маршрут для корня
    path('clients/<int:client_id>/edit/', views.client_edit, name='client_edit'),
    path('services/', views.service_list, name='service_list'),
    path('services/new/', views.service_create, name='service_create'),
    path('services/<int:service_id>/edit/', views.service_edit, name='service_edit'),
    path('services/<int:service_id>/delete/', views.service_delete, name='service_delete'),
]

if settings.DEBUG:
    import debug_toolbar
    urlpatterns = [path('__debug__/', include(debug_toolbar.urls))] + urlpatterns